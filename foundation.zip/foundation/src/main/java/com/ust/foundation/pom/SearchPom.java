package com.ust.foundation.pom;


import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchPom {
	WebDriver driver;
	
	public SearchPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//webelement to click search bar
	@FindBy(xpath = "//input[@class='search-box-text ui-autocomplete-input']")
	WebElement searchBar;
	
	//webelement for invalid search
	@FindBy(xpath = "//div[@class='no-result']")
	WebElement invalidSearch;
	
	//webelement to validate valid search
	@FindBy(xpath = "//div[@class='product-item']")
	List<WebElement> validSearch;
	
	//method to sperform search
	public void performSearch(String key) {
		searchBar.sendKeys(key);
		searchBar.sendKeys(Keys.ENTER);
	}
	
	//method to validate null search
	public boolean assertNullSearch() {
		Alert alert = driver.switchTo().alert();
		alert.accept();
		
		return true;  // if this much operations have been completed then the search have happened
	}
	
	//method to validate invalid search
	public boolean assertInvalidSearch() {
		return invalidSearch.isDisplayed();
	}
	
	//method to validate invalid search
	public boolean assertValidSearch() {
		return validSearch.size()>=1;
	}
}
