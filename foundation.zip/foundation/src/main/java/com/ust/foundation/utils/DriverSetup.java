package com.ust.foundation.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class DriverSetup {
	
	public static WebDriver driver;

	/**
     * Method to invoke Chrome browser with specific options.
     * @return The WebDriver object for Chrome.
     */
	public static WebDriver invokeChrome() {
//		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	    ChromeOptions options = new ChromeOptions();
	    options.addArguments("--disable-notifications");
	    driver = new ChromeDriver(options);
	    driver.manage().window().maximize();
	    return driver;
	}
	
	/**
     * Method to invoke Edge browser with specific options.
     * @return The WebDriver object for Edge.
     */
	public static WebDriver invokeEdge() {
	    EdgeOptions options = new EdgeOptions();
	    options.addArguments("--disable-notifications");
	    driver = new EdgeDriver(options);
	    driver.manage().window().maximize();
	    return driver;
	}
}
