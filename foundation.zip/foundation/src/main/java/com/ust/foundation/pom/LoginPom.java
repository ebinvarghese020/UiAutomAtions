package com.ust.foundation.pom;

import static org.testng.Assert.assertEquals;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.foundation.utils.FileIO;

public class LoginPom {
	WebDriver driver;
	Properties property;
	
	public LoginPom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
		property = FileIO.getProperties();
	}
	
	//webelement to click login at home page
	@FindBy(xpath = "//a[@class='ico-login']")
	WebElement clickLoginHomePage;
	
	//webelememnt to enter Email
	@FindBy(xpath = "//input[@class='email']")
	WebElement enterEmail;
	
	//webelememnt to enter Password
	@FindBy(xpath = "//input[@class='password']")
	WebElement enterPassword;
	
	//webelement to click login
	@FindBy(xpath = "//button[@class='button-1 login-button']")
	WebElement clickLoginButton;
	
	//webelement for null login
	@FindBy(xpath = "//div/span[@class='field-validation-error']")
	WebElement nullLogin;
	
	//webelement to check if logged in
	@FindBy(className = "ico-logout")
	WebElement logout;
	
	//webelement to check if logged in
	@FindBy(xpath = "//div[@class='message-error validation-summary-errors']")
	WebElement invalidLogin;
	
	public void signin(String mail, String password){
		clickLoginHomePage.click();
		enterEmail.sendKeys(mail);
		enterPassword.sendKeys(password);
		clickLoginButton.click();
	}
	
	public boolean assertValidLogin() {
		boolean res = false;
		res = logout.getText().equalsIgnoreCase("Log out");
		return res;
	}
	
	public boolean assertNullLogin() {
		return nullLogin.isDisplayed();
	}
	
	public boolean assertInvalidLogin() {
		return invalidLogin.isDisplayed();
	}
}
