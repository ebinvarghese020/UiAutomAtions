package com.ust.foundation.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHandle {
	/**
     * Method to read data from an Excel sheet.
     * @param path The path to the Excel file.
     * @param sheetName The name of the sheet in the Excel file.
     * @return A 2D array of strings representing the data in the sheet.
     * @throws IOException If an I/O error occurs.
     */
	public static String[][] readSheet(String path, String sheetName) throws IOException {
		FileInputStream file = new FileInputStream(new File(path));
		
		Workbook work = new XSSFWorkbook(file);
		
		Sheet sheet = work.getSheet(sheetName);
		
		int rowCount = sheet.getPhysicalNumberOfRows();
		
		Row row = sheet.getRow(0);
		
		int colCount = row.getPhysicalNumberOfCells();
		
		String[][] arr = new String[rowCount][colCount];
		
		DataFormatter df = new DataFormatter();
		for(int i = 0 ; i< rowCount; i++)
			for(int j = 0 ; j < colCount; j++) {
				arr[i][j] = df.formatCellValue(sheet.getRow(i).getCell(j));
			}
		
		
		return arr;
	}
}
