package com.ust.foundation.base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.foundation.utils.DriverSetup;
import com.ust.foundation.utils.FileIO;

public class Reuseable {
		private static WebDriver driver;
		public static String browser;
		public static Properties properties;
		
		
		/**
	     * Constructor for Reuseable class.
	     * @param driver The WebDriver object.
	     */
		public Reuseable(WebDriver driver) {
			this.driver = driver;
			properties = FileIO.getProperties();
		}
		
		/**
	     * Method to invoke the browser based on the provided URL.
	     * @param url The URL to open in the browser.
	     * @return The WebDriver object.
	     */
		//invoke browser
		public static WebDriver invokeBrowser(String url) {
			browser = "chrome";
			try
				{
					if(browser.equals("chrome")) {
						driver = DriverSetup.invokeChrome();
					}
					else if(browser.equals("edge")) {
						driver = DriverSetup.invokeEdge();
					}
					else {
						throw new Exception("Invalid browser name provided in property file");
					}
				}catch(Exception e){
					e.printStackTrace();
				}
			return driver;
			
		}
		
		/**********open website *********/
		/**
	     * Method to open the website based on the baseUrl from the configuration.
	     */
		public void openWebsite() {
			properties=FileIO.getProperties();
			String browser = properties.getProperty("URL");
			try {
				driver.get(browser);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		/**
	     * Method to assert the current URL.
	     * @param url The expected URL.
	     * @param driver The WebDriver object.
	     * @return True if the current URL contains the expected URL, false otherwise.
	     */
		public boolean assertUrl(String url, WebDriver driver) {
			return driver.getCurrentUrl().contains(url);
		}
		
		/**
		 * Method to take a screenshot.
		 * @param driver The WebDriver object.
		 * @param filepath The file path where the screenshot will be saved.
		 * @return True if the screenshot is taken successfully, false otherwise.
		 */
		public static void takeScreenShot(String filepath) {
			TakesScreenshot takeScreenShot = (TakesScreenshot)driver;
			File srcFile = takeScreenShot.getScreenshotAs(OutputType.FILE);
			File destFile = new File(filepath);
			try {
				FileUtils.copyFile(srcFile, destFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		/**
		 * Waits for the given WebElement to be clickable for the specified duration.
		 * @param element The WebElement to wait for.
		 * @param sec The duration in seconds to wait for the element to be clickable.
		 * @return The clickable WebElement if found within the specified duration, null otherwise.
		 */
		public static WebElement waitPgm(WebElement element, int sec) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(sec));
			WebElement res = wait.until(ExpectedConditions.elementToBeClickable(element));
			return res;
		}
		
		/**
		 * Accepts an alert dialog.
		 * @return True if the alert was accepted successfully, false otherwise.
		 */
		public void alertPgm() {
			Alert alert = driver.switchTo().alert();
			alert.accept();
		}
}
