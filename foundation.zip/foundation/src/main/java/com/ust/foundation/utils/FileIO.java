package com.ust.foundation.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class FileIO {
	public static Properties properties;
	
	/**
     * Method to load properties from a properties file.
     */
	public static Properties getProperties() {
		if(properties == null) {
			properties = new Properties();
			try {
				FileInputStream file = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\objectConfig\\testngConfig.properties" );
				properties.load(file);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return properties;
	}
}
