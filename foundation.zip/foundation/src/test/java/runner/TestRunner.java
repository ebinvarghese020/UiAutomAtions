package runner;

import org.testng.annotations.Listeners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@Listeners(com.ust.foundation.utils.ExtentReportsListener.class)
@CucumberOptions(
        features = {"src/test/resources/features"},
        glue = {"com.ust.foundation.stepdefenition"},
        plugin = {
                "pretty:target/prettyReport.txt", "html:target/cucumber", "rerun:target/rerun.txt"
               ,
               "pretty",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
        monochrome = true

                )
public class TestRunner extends AbstractTestNGCucumberTests {

}
