package com.ust.foundation.testngTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.foundation.base.Reuseable;
import com.ust.foundation.pom.LoginPom;
import com.ust.foundation.utils.ExcelHandle;
import com.ust.foundation.utils.FileIO;

@Listeners(com.ust.foundation.utils.ExtentReportsListener.class)
//Defines a class named LoginTest
public class LoginTest {  

	WebDriver driver;  // Declares a WebDriver variable named driver
	Reuseable reuse;  // Declares a Reuseable variable named reuse
	Properties property;
	LoginPom login;
	
	// Indicates that this method should run before each test method
	@BeforeMethod  
	public void setUp() {  
		property = FileIO.getProperties();
		String browser = property.getProperty("BROWSER");
		driver = Reuseable.invokeBrowser(browser);  // Calls the invokeBrowser to invoke driver
		reuse = new Reuseable(driver);  
		reuse.openWebsite();  // Calls the openWebsite method on the reuse object
		
		login = new LoginPom(driver);
	}

	//method to test invalid login
	@Test (priority = 1, dataProvider = "getData1")
	public void testInvalidLogin(String name, String password) {
		login.signin(name, password);
		assertTrue(login.assertInvalidLogin());
	}
	
	//method to test null login
	@Test (priority = 2)
	public void testNullLogin() {
		login.signin("", "");
		assertTrue(login.assertNullLogin());
	}

	
	// for login to work properly it requires the user to signup and the value are active only for less than 30 mins
	// so pls create user with VALIDNAME=testng@gmail.com and VALIDPASSWORD=Testng@123 before execution
	//method to test valid login
	@Test (priority = 3)
	public  void testValidLogin() {
		login.signin(property.getProperty("VALIDNAME"), property.getProperty("VALIDPASSWORD"));
		assertTrue(login.assertValidLogin());
	}
	
	@DataProvider(name="getData1")
	public String[][] getFromExcelSheet1() {
		try {
			String[][] arr = ExcelHandle.readSheet(System.getProperty("user.dir")+"/src/test/resources/testData/testData.xlsx", "Sheet1");
			return arr;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	
	}
	
	@AfterMethod
	public void afterTest(ITestResult result) {
		driver.close();
	}
}
