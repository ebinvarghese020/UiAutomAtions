package com.ust.foundation.stepdefenition;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.foundation.base.Reuseable;
import com.ust.foundation.pom.SearchPom;
import com.ust.foundation.utils.FileIO;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ValidateSearch {
	
	WebDriver driver;
	Reuseable reuse;
	Properties property;
	SearchPom search;
	
	/**
     * Constructor for ValidateSearch class.
     */
	public ValidateSearch() {
    	driver = Hooks.driver;
		reuse = new Reuseable(driver);  
		property = FileIO.getProperties();
		search = new SearchPom(driver);
	}
	
	@Given("User already on home page")
	public void user_already_on_home_page() {
	    reuse.openWebsite();
	}
	@When("User search for {string}")
	public void user_search_for(String key) {
	    search.performSearch(key);
	}
	@Then("I validate that that no search result is found")
	public void i_validate_that_that_no_search_result_is_found() {
		assertTrue(search.assertInvalidSearch());
	}
	
	@Then("I validate the output")
	public void i_validate_the_output() {
	    
	}
	
	@Then("I validate the alert the null value pops up.")
	public void i_validate_the_alert_the_null_value_pops_up() {
	    assertTrue(search.assertNullSearch());
	}
}
